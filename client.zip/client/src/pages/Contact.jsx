import ContactSection from '../components/ContactSection';

function Contact() {
  return (
    <>
      <ContactSection />
    </>
  );
}

export default Contact;