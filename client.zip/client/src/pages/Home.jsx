const Home = () => {
  return (
    <div className="container mt-5">
      <h1>Welcome to Best Cars</h1>
      <p>This is the homepage.</p>
    </div>
  );
};

export default Home;